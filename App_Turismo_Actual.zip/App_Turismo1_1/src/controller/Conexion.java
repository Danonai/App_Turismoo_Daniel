package controller;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

//creo una clase
public class Conexion {

	//creo un metodo de tipo Connection llamado conectarBD
	
	public Connection conectarBD() {
		//Creo un objeto de la clase Conexion que en esta linea no contiene nada.
		Connection conexion = null;
		//Se contiene en un try para sondear posibles errores
		try {
			//En el objeto conexion se conecta a la base de datos usando el metodo DriverManager.getConnection
			//que recibe los parametros
		conexion=DriverManager.getConnection("jdbc:mysql://localhost:3306/bd_turismo2","root","2556229");	
		System.out.println("Connected Whit the database successfully");	
		
		//Atrapa cualquier error a excepcion que ocurra en try e imprime un mensaje
		} catch (SQLException e){
			System.out.println("Error while connecting to the database"+e.getMessage());
			
		}
		 return conexion; 
		 
	}
	
}
