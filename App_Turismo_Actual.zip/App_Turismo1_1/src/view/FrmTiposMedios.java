package view;


import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SwingConstants;
import java.awt.Font;
import model.TipoMedioclass;
public class FrmTiposMedios extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtNombre;
	private JTextField txtObservacion;
	private JTextField txtTipoMe;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmTiposMedios frame = new FrmTiposMedios();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmTiposMedios() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 470, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Nombre:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel_1.setBounds(62, 90, 74, 14);
		contentPane.add(lblNewLabel_1);
		
		txtNombre = new JTextField();
		txtNombre.setColumns(10);
		txtNombre.setBounds(215, 89, 86, 20);
		contentPane.add(txtNombre);
		
		JLabel lblNewLabel_1_1 = new JLabel("Observación:");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel_1_1.setBounds(62, 133, 102, 14);
		contentPane.add(lblNewLabel_1_1);
		
		txtObservacion = new JTextField();
		txtObservacion.setColumns(10);
		txtObservacion.setBounds(210, 115, 112, 54);
		contentPane.add(txtObservacion);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		btnRegistrar.addMouseListener(new MouseAdapter() {
			@Override
			/*Escribe Aquí*/
			public void mouseClicked(MouseEvent e) {
			TipoMedioclass cr = new TipoMedioclass();
			
			cr.create(txtNombre.getText(),txtObservacion.getText());
		
			}
		});
		btnRegistrar.setBounds(343, 66, 101, 23);
		contentPane.add(btnRegistrar);
		
		JLabel lblNewLabel = new JLabel("Sistema de Gestión de Tipos de Medios");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(48, 21, 343, 14);
		contentPane.add(lblNewLabel);
		
		JButton btnEliminar = new JButton("Eliminar");
		btnEliminar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				TipoMedioclass Dl = new TipoMedioclass();
				
				Dl.delete(Integer.parseInt(txtTipoMe.getText()));
				txtTipoMe.setText(getName());
				
			}
		});
		btnEliminar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		btnEliminar.setBounds(342, 95, 102, 23);
		contentPane.add(btnEliminar);
		
		JLabel lblTipoM = new JLabel("Id Tipos de Medios");
		lblTipoM.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		lblTipoM.setBounds(62, 65, 143, 14);
		contentPane.add(lblTipoM);
		
		txtTipoMe = new JTextField();
		txtTipoMe.setColumns(10);
		txtTipoMe.setBounds(215, 64, 86, 20);
		contentPane.add(txtTipoMe);
		
		JButton btnActualizar = new JButton("Actualizar");
		btnActualizar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				TipoMedioclass Up = new  TipoMedioclass();
				Up.update(Integer.parseInt(txtTipoMe.getText()),txtNombre.getText(),txtObservacion.getText());
			}
		});
		btnActualizar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		btnActualizar.setBounds(337, 129, 107, 23);
		contentPane.add(btnActualizar);
		
		JButton btnMostrar = new JButton("Mostrar");
		btnMostrar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				TipoMedioclass Ro = new  TipoMedioclass();
				Ro.readOne(Integer.parseInt(txtTipoMe.getText()), txtNombre, txtObservacion);
				
			}
		});
		btnMostrar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		btnMostrar.setBounds(337, 163, 107, 23);
		contentPane.add(btnMostrar);
	}
	
	
	
}
