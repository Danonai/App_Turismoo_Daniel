package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.Companiasclass;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FrmCompanias extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtRazonsocial;
	private JTextField txtDireccion;
	private JTextField txtCorreo;
	private JTextField txtTelefono;
	private JTextField txtFechaCreacion;
	private JTextField txtWeb;
	private JTextField txtIdCompanias;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmCompanias frame = new FrmCompanias();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmCompanias() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 398, 303);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblRaznSocial = new JLabel("Razón Social");
		lblRaznSocial.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblRaznSocial.setBounds(24, 99, 89, 14);
		contentPane.add(lblRaznSocial);
		
		JLabel lblDireccin = new JLabel("Dirección");
		lblDireccin.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblDireccin.setBounds(24, 124, 82, 14);
		contentPane.add(lblDireccin);
		
		JLabel lblCorreo = new JLabel("Correo");
		lblCorreo.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblCorreo.setBounds(24, 149, 82, 14);
		contentPane.add(lblCorreo);
		
		JLabel lblTelefono = new JLabel("Telefono");
		lblTelefono.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblTelefono.setBounds(24, 174, 82, 14);
		contentPane.add(lblTelefono);
		
		JLabel lblFechaDeCreacin = new JLabel("Fecha De Creación");
		lblFechaDeCreacin.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblFechaDeCreacin.setBounds(20, 199, 127, 14);
		contentPane.add(lblFechaDeCreacin);
		
		JLabel lbltexto = new JLabel("Web");
		lbltexto.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lbltexto.setBounds(24, 224, 82, 14);
		contentPane.add(lbltexto);
		
		txtRazonsocial = new JTextField();
		txtRazonsocial.setColumns(10);
		txtRazonsocial.setBounds(155, 99, 86, 20);
		contentPane.add(txtRazonsocial);
		
		txtDireccion = new JTextField();
		txtDireccion.setColumns(10);
		txtDireccion.setBounds(155, 123, 86, 20);
		contentPane.add(txtDireccion);
		
		txtCorreo = new JTextField();
		txtCorreo.setColumns(10);
		txtCorreo.setBounds(155, 148, 86, 20);
		contentPane.add(txtCorreo);
		
		txtTelefono = new JTextField();
		txtTelefono.setColumns(10);
		txtTelefono.setBounds(155, 173, 86, 20);
		contentPane.add(txtTelefono);
		
		txtFechaCreacion = new JTextField();
		txtFechaCreacion.setColumns(10);
		txtFechaCreacion.setBounds(155, 198, 86, 20);
		contentPane.add(txtFechaCreacion);
		
		txtWeb = new JTextField();
		txtWeb.setColumns(10);
		txtWeb.setBounds(155, 223, 86, 20);
		contentPane.add(txtWeb);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				Companiasclass crear = new Companiasclass();
				
				crear.create(txtRazonsocial.getText(), txtDireccion.getText(),txtCorreo.getText(),txtTelefono.getText(),txtFechaCreacion.getText(),txtWeb.getText());
				
				
			}
		});
		btnRegistrar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnRegistrar.setBounds(255, 66, 113, 23);
		contentPane.add(btnRegistrar);
		
		JLabel lblNewLabel = new JLabel("Sistema de Gestión de Compañias");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel.setBounds(81, 24, 287, 14);
		contentPane.add(lblNewLabel);
		
		JButton btnEliminar = new JButton("Eliminar");
		btnEliminar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Companiasclass Dl = new Companiasclass();
				Dl.delete(Integer.parseInt(txtIdCompanias.getText()));
				
				txtIdCompanias.setText("");
			}
		});
		btnEliminar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnEliminar.setBounds(265, 134, 99, 23);
		contentPane.add(btnEliminar);
		
		JLabel lblIdCompanias = new JLabel("Id Compañias");
		lblIdCompanias.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblIdCompanias.setBounds(24, 70, 89, 14);
		contentPane.add(lblIdCompanias);
		
		txtIdCompanias = new JTextField();
		txtIdCompanias.setColumns(10);
		txtIdCompanias.setBounds(155, 68, 86, 20);
		contentPane.add(txtIdCompanias);
		
		JButton btnActualizar = new JButton("Actualizar");
		btnActualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnActualizar.addMouseListener(new MouseAdapter() {
			@Override//Actualizar
			public void mouseClicked(MouseEvent e) {
				Companiasclass Up = new Companiasclass();
				Up.update(Integer.parseInt(txtIdCompanias.getText()), txtRazonsocial.getText(), txtDireccion.getText(),txtCorreo.getText(),txtTelefono.getText(),txtFechaCreacion.getText(),txtWeb.getText());
				
			}
		});
		btnActualizar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnActualizar.setBounds(263, 165, 99, 23);
		contentPane.add(btnActualizar);
		
		JButton btnMostrar = new JButton("Mostrar");
		btnMostrar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				Companiasclass Ro = new Companiasclass();
				Ro.readOne(Integer.parseInt(txtIdCompanias.getText()), txtRazonsocial, txtDireccion, txtCorreo, txtTelefono, txtFechaCreacion, txtWeb);
			}
		});
		btnMostrar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnMostrar.setBounds(263, 195, 99, 23);
		contentPane.add(btnMostrar);
	}
}
