package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.Mediosclass;

import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class FrmMedios extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtNombre;
	private JTextField txtObservacion;
	private JTextField txtIdMedios;
	private JTextField txtFkMedios;
	private JButton btnEliminar;
	private JButton btnActualizar;
	private JButton btnMostrar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmMedios frame = new FrmMedios();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmMedios() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 455, 248);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ID Medios");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel.setBounds(42, 61, 125, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Observación");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_1.setBounds(42, 127, 125, 14);
		contentPane.add(lblNewLabel_1);
		
		txtNombre = new JTextField();
		txtNombre.setBounds(176, 93, 86, 20);
		contentPane.add(txtNombre);
		txtNombre.setColumns(10);
		
		txtObservacion = new JTextField();
		txtObservacion.setBounds(176, 124, 86, 20);
		contentPane.add(txtObservacion);
		txtObservacion.setColumns(10);
		
		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNombre.setBounds(42, 96, 125, 14);
		contentPane.add(lblNombre);
		
		JLabel lblFkTiposDe = new JLabel("Fk Tipos de Medios");
		lblFkTiposDe.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblFkTiposDe.setBounds(42, 156, 125, 14);
		contentPane.add(lblFkTiposDe);
		
		txtIdMedios = new JTextField();
		txtIdMedios.setColumns(10);
		txtIdMedios.setBounds(176, 61, 86, 20);
		contentPane.add(txtIdMedios);
		
		txtFkMedios = new JTextField();
		txtFkMedios.setColumns(10);
		txtFkMedios.setBounds(176, 153, 86, 20);
		contentPane.add(txtFkMedios);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				Mediosclass crear = new Mediosclass();
				crear.create(txtNombre.getText(), txtObservacion.getText(),Integer.parseInt(txtFkMedios.getText()));
				
			}
		});
		btnRegistrar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnRegistrar.setBounds(286, 61, 125, 23);
		contentPane.add(btnRegistrar);
		
		btnEliminar = new JButton("Eliminar");
		btnEliminar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Mediosclass Dl = new Mediosclass();
				Dl.delete(Integer.parseInt(txtIdMedios.getText()));
				txtIdMedios.setText("");
				
			}
		});
		btnEliminar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnEliminar.setBounds(286, 95, 125, 23);
		contentPane.add(btnEliminar);
		
		btnActualizar = new JButton("Actualizar");
		btnActualizar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				Mediosclass Up = new Mediosclass();
				Up.update(Integer.parseInt(txtIdMedios.getText()),txtNombre.getText(),txtObservacion.getText(),Integer.parseInt(txtFkMedios.getText()));
			}
		});
		btnActualizar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnActualizar.setBounds(286, 128, 125, 23);
		contentPane.add(btnActualizar);
		
		btnMostrar = new JButton("Mostrar");
		btnMostrar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Mediosclass Ro = new Mediosclass();
				Ro.readOne(Integer.parseInt(txtIdMedios.getText()), txtNombre, txtObservacion, txtFkMedios);
			}
		});
		btnMostrar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnMostrar.setBounds(286, 162, 125, 23);
		contentPane.add(btnMostrar);
	}

}
