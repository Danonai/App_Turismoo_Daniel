package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.Origenclass;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class FrmOrigen extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtIdOrigen;
	private JTextField txtNombre;
	private JTextField txtDescripcion;
	private JButton btnEliminar;
	private JButton btnActualizar;
	private JButton btnMostrar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmOrigen frame = new FrmOrigen();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmOrigen() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblIdOrigen = new JLabel("Id Origen");
		lblIdOrigen.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblIdOrigen.setBounds(51, 63, 75, 14);
		contentPane.add(lblIdOrigen);
		
		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNombre.setBounds(51, 111, 75, 14);
		contentPane.add(lblNombre);
		
		JLabel lblDescripcin = new JLabel("Descripción");
		lblDescripcin.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblDescripcin.setBounds(51, 161, 75, 14);
		contentPane.add(lblDescripcin);
		
		txtIdOrigen = new JTextField();
		txtIdOrigen.setBounds(148, 62, 86, 20);
		contentPane.add(txtIdOrigen);
		txtIdOrigen.setColumns(10);
		
		txtNombre = new JTextField();
		txtNombre.setColumns(10);
		txtNombre.setBounds(148, 110, 86, 20);
		contentPane.add(txtNombre);
		
		txtDescripcion = new JTextField();
		txtDescripcion.setColumns(10);
		txtDescripcion.setBounds(148, 160, 86, 20);
		contentPane.add(txtDescripcion);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Origenclass cr = new Origenclass();
				cr.create(txtNombre.getText(), txtDescripcion.getText());
				
			}
		});
		btnRegistrar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnRegistrar.setBounds(264, 67, 107, 23);
		contentPane.add(btnRegistrar);
		
		btnEliminar = new JButton("Eliminar");
		btnEliminar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			Origenclass Dl = new Origenclass();
				Dl.delete(Integer.parseInt(txtIdOrigen.getText()));
				txtIdOrigen.setText("");
			}
		});
		btnEliminar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnEliminar.setBounds(265, 100, 107, 23);
		contentPane.add(btnEliminar);
		
		btnActualizar = new JButton("Actualizar");
		btnActualizar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				 
				Origenclass Up = new Origenclass();
				Up.update(Integer.parseInt(txtIdOrigen.getText()),txtNombre.getText(),txtDescripcion.getText());
			}
		});
		btnActualizar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnActualizar.setBounds(264, 135, 107, 23);
		contentPane.add(btnActualizar);
		
		btnMostrar = new JButton("Mostrar");
		btnMostrar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Origenclass Ro = new Origenclass();
				Ro.readOne(Integer.parseInt(txtIdOrigen.getText()), txtNombre, txtDescripcion);
			}
		});
		btnMostrar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnMostrar.setBounds(264, 169, 107, 23);
		contentPane.add(btnMostrar);
	}

}
