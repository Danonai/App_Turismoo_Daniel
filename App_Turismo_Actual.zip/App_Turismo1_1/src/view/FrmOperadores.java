package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.Operadoresclass;

import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


public class FrmOperadores extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtTipoDocumento;
	private JTextField txtDocumento;
	private JTextField txtNombres;
	private JTextField txtApellidos;
	private JTextField txtDireccion;
	private JTextField txtCorreo;
	private JTextField txtTelefono;
	private JTextField txtFkMatricula;
	private JTextField txtIdOperador;
	private JButton btnEliminar;
	private JButton btnActualizar;
	private JButton btnMostrar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmOperadores frame = new FrmOperadores();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmOperadores() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 475, 400);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtTipoDocumento = new JTextField();
		txtTipoDocumento.setBounds(241, 52, 86, 20);
		contentPane.add(txtTipoDocumento);
		txtTipoDocumento.setColumns(10);
		
		txtDocumento = new JTextField();
		txtDocumento.setColumns(10);
		txtDocumento.setBounds(241, 93, 86, 20);
		contentPane.add(txtDocumento);
		
		txtNombres = new JTextField();
		txtNombres.setColumns(10);
		txtNombres.setBounds(241, 129, 86, 20);
		contentPane.add(txtNombres);
		
		txtApellidos = new JTextField();
		txtApellidos.setColumns(10);
		txtApellidos.setBounds(241, 168, 86, 20);
		contentPane.add(txtApellidos);
		
		txtDireccion = new JTextField();
		txtDireccion.setColumns(10);
		txtDireccion.setBounds(241, 210, 86, 20);
		contentPane.add(txtDireccion);
		
		txtCorreo = new JTextField();
		txtCorreo.setColumns(10);
		txtCorreo.setBounds(241, 241, 86, 20);
		contentPane.add(txtCorreo);
		
		txtTelefono = new JTextField();
		txtTelefono.setColumns(10);
		txtTelefono.setBounds(243, 270, 86, 20);
		contentPane.add(txtTelefono);
		
		txtFkMatricula = new JTextField();
		txtFkMatricula.setColumns(10);
		txtFkMatricula.setBounds(243, 309, 86, 20);
		contentPane.add(txtFkMatricula);
		
		JLabel lblNewLabel = new JLabel("Tipo de Documento");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel.setBounds(83, 54, 141, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNumeroDeDocumento = new JLabel("Numero de Documento");
		lblNumeroDeDocumento.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNumeroDeDocumento.setBounds(83, 94, 166, 14);
		contentPane.add(lblNumeroDeDocumento);
		
		JLabel lblNombres = new JLabel("Nombres");
		lblNombres.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNombres.setBounds(83, 130, 112, 14);
		contentPane.add(lblNombres);
		
		JLabel lblApellidos = new JLabel("Apellidos");
		lblApellidos.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblApellidos.setBounds(83, 169, 112, 14);
		contentPane.add(lblApellidos);
		
		JLabel lblDireccin = new JLabel("Dirección");
		lblDireccin.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblDireccin.setBounds(83, 211, 112, 14);
		contentPane.add(lblDireccin);
		
		JLabel lblCorreo = new JLabel("Correo");
		lblCorreo.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblCorreo.setBounds(83, 242, 112, 14);
		contentPane.add(lblCorreo);
		
		JLabel lblTelfono = new JLabel("Teléfono");
		lblTelfono.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblTelfono.setBounds(87, 275, 112, 14);
		contentPane.add(lblTelfono);
		
		JLabel lblFkMatricula = new JLabel("Fk Matricula");
		lblFkMatricula.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblFkMatricula.setBounds(87, 314, 112, 14);
		contentPane.add(lblFkMatricula);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				Operadoresclass cr = new Operadoresclass();
				
				cr.create(Integer.parseInt(txtTipoDocumento.getText()),Integer.parseInt(txtDocumento.getText()),txtNombres.getText(),txtApellidos.getText(), txtDireccion.getText(),txtCorreo.getText(),txtTelefono.getText(),txtFkMatricula.getText());
				
			}
			
			
	
		});
		btnRegistrar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnRegistrar.setBounds(337, 63, 112, 23);
		contentPane.add(btnRegistrar);
		
		JLabel lblNewLabel_1 = new JLabel("Id Operador");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_1.setBounds(83, 21, 86, 14);
		contentPane.add(lblNewLabel_1);
		
		txtIdOperador = new JTextField();
		txtIdOperador.setBounds(241, 19, 86, 20);
		contentPane.add(txtIdOperador);
		txtIdOperador.setColumns(10);
		
		btnEliminar = new JButton("Eliminar");
		btnEliminar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Operadoresclass Dl = new Operadoresclass();
				Dl.delete(Integer.parseInt(txtIdOperador.getText()));
				txtIdOperador.setText("");
			}
		});
		btnEliminar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnEliminar.setBounds(337, 91, 112, 23);
		contentPane.add(btnEliminar);
		
		btnActualizar = new JButton("Actualizar");
		btnActualizar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				Operadoresclass Up  = new Operadoresclass();
				Up.update(Integer.parseInt(txtIdOperador.getText()),Integer.parseInt(txtTipoDocumento.getText()),Integer.parseInt(txtDocumento.getText()),txtNombres.getText(),txtApellidos.getText(),txtDireccion.getText(),txtCorreo.getText(),txtTelefono.getText(),txtFkMatricula.getText());
				
			}
		});
		btnActualizar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnActualizar.setBounds(337, 121, 109, 23);
		contentPane.add(btnActualizar);
		
		btnMostrar = new JButton("Mostrar");
		btnMostrar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				Operadoresclass Ro  = new Operadoresclass();
				Ro.readOne(Integer.parseInt(txtIdOperador.getText()), txtTipoDocumento, txtDocumento, txtNombres, txtApellidos, txtDireccion, txtCorreo, txtTelefono, txtFkMatricula);
			}
		});
		btnMostrar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnMostrar.setBounds(337, 148, 109, 23);
		contentPane.add(btnMostrar);
	}
}
