
package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import model.Promotoresclass;

public class FrmPromotores extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtTipoDocumento;
	private JTextField txtDocumento;
	private JTextField txtNombres;
	private JTextField txtApellidos;
	private JTextField txtDireccion;
	private JTextField txtCorreoPerso;
	private JTextField txtCorreoCorp;
	private JTextField txtFechaNacimiento;
	private JTextField txtTelefono;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_3;
	private JTextField txtIdPromotores;
	private JButton btnEliminar;
	private JButton btnActualizar;
	private JButton btnMostrar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmPromotores frame = new FrmPromotores();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmPromotores() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 499, 370);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel_1 = new JLabel("Tipo de Documento: ");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_1.setBounds(72, 69, 145, 14);
		contentPane.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("Número de Documento:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_2.setBounds(72, 94, 164, 14);
		contentPane.add(lblNewLabel_2);

		JLabel lblNewLabel_4 = new JLabel("Nombres:");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_4.setBounds(75, 121, 87, 14);
		contentPane.add(lblNewLabel_4);

		JLabel lblNewLabel_5 = new JLabel("Apellidos:");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_5.setBounds(75, 146, 87, 14);
		contentPane.add(lblNewLabel_5);

		JLabel lblNewLabel_6 = new JLabel("Dirección:");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_6.setBounds(75, 171, 87, 14);
		contentPane.add(lblNewLabel_6);

		JLabel lblNewLabel_7 = new JLabel("Correo Personal:");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_7.setBounds(75, 195, 114, 15);
		contentPane.add(lblNewLabel_7);

		JLabel lblNewLabel_8 = new JLabel("Correo Corporativo:");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_8.setBounds(75, 221, 144, 14);
		contentPane.add(lblNewLabel_8);

		JLabel lblNewLabel_9 = new JLabel("Fecha de Nacimiento:");
		lblNewLabel_9.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_9.setBounds(75, 246, 139, 14);
		contentPane.add(lblNewLabel_9);

		JLabel lblNewLabel_9_1 = new JLabel("Telefono: ");
		lblNewLabel_9_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_9_1.setBounds(75, 272, 87, 14);
		contentPane.add(lblNewLabel_9_1);

		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				Promotoresclass crear = new Promotoresclass();

				crear.create(Integer.parseInt(txtTipoDocumento.getText()),Integer.parseInt(txtDocumento.getText()), txtNombres.getText(), txtApellidos.getText(),
								txtDireccion.getText(), txtCorreoPerso.getText(), txtCorreoCorp.getText(), txtFechaNacimiento.getText(),txtTelefono.getText());

			}
		});
		btnRegistrar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnRegistrar.setBounds(330, 90, 114, 23);
		contentPane.add(btnRegistrar);

		txtTipoDocumento = new JTextField();
		txtTipoDocumento.setColumns(10);
		txtTipoDocumento.setBounds(233, 68, 86, 20);
		contentPane.add(txtTipoDocumento);

		txtDocumento = new JTextField();
		txtDocumento.setColumns(10);
		txtDocumento.setBounds(233, 93, 86, 20);
		contentPane.add(txtDocumento);

		txtNombres = new JTextField();
		txtNombres.setColumns(10);
		txtNombres.setBounds(234, 120, 86, 20);
		contentPane.add(txtNombres);

		txtApellidos = new JTextField();
		txtApellidos.setColumns(10);
		txtApellidos.setBounds(234, 145, 86, 20);
		contentPane.add(txtApellidos);

		txtDireccion = new JTextField();
		txtDireccion.setColumns(10);
		txtDireccion.setBounds(234, 170, 86, 20);
		contentPane.add(txtDireccion);

		txtCorreoPerso = new JTextField();
		txtCorreoPerso.setColumns(10);
		txtCorreoPerso.setBounds(234, 195, 86, 20);
		contentPane.add(txtCorreoPerso);

		txtCorreoCorp = new JTextField();
		txtCorreoCorp.setColumns(10);
		txtCorreoCorp.setBounds(234, 220, 86, 20);
		contentPane.add(txtCorreoCorp);

		txtFechaNacimiento = new JTextField();
		txtFechaNacimiento.setColumns(10);
		txtFechaNacimiento.setBounds(234, 245, 86, 20);
		contentPane.add(txtFechaNacimiento);

		txtTelefono = new JTextField();
		txtTelefono.setColumns(10);
		txtTelefono.setBounds(234, 271, 86, 20);
		contentPane.add(txtTelefono);

		lblNewLabel = new JLabel("Sistema de Gestión de los Promotores");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel.setBounds(72, 11, 254, 14);
		contentPane.add(lblNewLabel);
		
		lblNewLabel_3 = new JLabel("Id Promotores");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_3.setBounds(72, 44, 145, 14);
		contentPane.add(lblNewLabel_3);
		
		txtIdPromotores = new JTextField();
		txtIdPromotores.setColumns(10);
		txtIdPromotores.setBounds(233, 42, 86, 20);
		contentPane.add(txtIdPromotores);
		
		btnEliminar = new JButton("Eliminar");
		btnEliminar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Promotoresclass Dl = new Promotoresclass();
				Dl.delete(Integer.parseInt(txtIdPromotores.getText()));
				txtIdPromotores.setText("");
			}
		});
		btnEliminar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnEliminar.setBounds(330, 117, 114, 23);
		contentPane.add(btnEliminar);
		
		btnActualizar = new JButton("Actualizar");
		btnActualizar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Promotoresclass Up = new  Promotoresclass();
				Up.update(Integer.parseInt(txtIdPromotores.getText()),Integer.parseInt(txtTipoDocumento.getText()),Integer.parseInt(txtDocumento.getText()),txtNombres.getText(),txtApellidos.getText(),txtDireccion.getText(),txtCorreoPerso.getText(),txtCorreoCorp.getText(),txtFechaNacimiento.getText(),txtTelefono.getText());
				
			}
		});
		btnActualizar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnActualizar.setBounds(330, 142, 114, 23);
		contentPane.add(btnActualizar);
		
		btnMostrar = new JButton("Mostrar");
		btnMostrar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				Promotoresclass Ro = new  Promotoresclass();
				Ro.readOne(Integer.parseInt(txtIdPromotores.getText()), txtTipoDocumento, txtDocumento, txtNombres, txtApellidos, txtDireccion, txtCorreoPerso, txtCorreoCorp, txtFechaNacimiento, txtTelefono, txtApellidos);
			}
		});
		btnMostrar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnMostrar.setBounds(330, 168, 114, 23);
		contentPane.add(btnMostrar);
	}

}
