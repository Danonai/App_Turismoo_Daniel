package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.Paquetesclass;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class FrmPaquetes extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtIdpaquetes;
	private JTextField txtIdDestino;
	private JTextField txtIdOrigen;
	private JTextField txtFechaVenta;
	private JTextField txtHoraVenta;
	private JTextField txtHoraSalida;
	private JTextField txtFechaEjecucion;
	private JTextField txtObservacion;
	private JTextField txtFkClientes;
	private JTextField txtFkPromotor;
	private JTextField txtFkAgencia;
	private JTextField txtFkMedio;
	private JTextField txtPrecios;
	private JTextField txtFkMatricula;
	private JButton btnEliminar;
	private JButton btnActualizar;
	private JButton btnMostrar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmPaquetes frame = new FrmPaquetes();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmPaquetes() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 479, 466);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Id Destino");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel.setBounds(75, 55, 71, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblFechaDeVenta = new JLabel("Fecha de Venta");
		lblFechaDeVenta.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblFechaDeVenta.setBounds(75, 103, 107, 14);
		contentPane.add(lblFechaDeVenta);
		
		JLabel lblHoraDeVenta = new JLabel("Hora de Venta");
		lblHoraDeVenta.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblHoraDeVenta.setBounds(75, 128, 107, 14);
		contentPane.add(lblHoraDeVenta);
		
		JLabel lblHoraDeSalida = new JLabel("Hora de Salida");
		lblHoraDeSalida.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblHoraDeSalida.setBounds(75, 153, 112, 14);
		contentPane.add(lblHoraDeSalida);
		
		JLabel lblFechaDeEjecucin = new JLabel("Fecha de Ejecución");
		lblFechaDeEjecucin.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblFechaDeEjecucin.setBounds(75, 178, 132, 14);
		contentPane.add(lblFechaDeEjecucin);
		
		JLabel lblObservacin = new JLabel("Observación");
		lblObservacin.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblObservacin.setBounds(75, 203, 92, 14);
		contentPane.add(lblObservacin);
		
		JLabel lblFkClientes = new JLabel("Fk Clientes");
		lblFkClientes.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblFkClientes.setBounds(75, 228, 98, 14);
		contentPane.add(lblFkClientes);
		
		JLabel lblFkPromotor = new JLabel("Fk Promotor");
		lblFkPromotor.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblFkPromotor.setBounds(75, 251, 92, 14);
		contentPane.add(lblFkPromotor);
		
		JLabel lblNewLabel_8 = new JLabel("Fk Agencia");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_8.setBounds(75, 276, 92, 14);
		contentPane.add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("Fk Medio");
		lblNewLabel_9.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_9.setBounds(75, 301, 92, 14);
		contentPane.add(lblNewLabel_9);
		
		JLabel lblNewLabel_10 = new JLabel(" Precios");
		lblNewLabel_10.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_10.setBounds(75, 326, 92, 14);
		contentPane.add(lblNewLabel_10);
		
		JLabel lblNewLabel_11 = new JLabel("Fk Matricula");
		lblNewLabel_11.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_11.setBounds(75, 354, 87, 14);
		contentPane.add(lblNewLabel_11);
		
		JLabel lblNewLabel_12 = new JLabel("Id Origen");
		lblNewLabel_12.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_12.setBounds(75, 80, 71, 14);
		contentPane.add(lblNewLabel_12);
		
		JLabel lblNewLabel_1_1 = new JLabel("Id Paquetes");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_1_1.setBounds(75, 30, 92, 14);
		contentPane.add(lblNewLabel_1_1);
		
		txtIdpaquetes = new JTextField();
		txtIdpaquetes.setBounds(219, 28, 86, 20);
		contentPane.add(txtIdpaquetes);
		txtIdpaquetes.setColumns(10);
		
		txtIdDestino = new JTextField();
		txtIdDestino.setColumns(10);
		txtIdDestino.setBounds(219, 53, 86, 20);
		contentPane.add(txtIdDestino);
		
		txtIdOrigen = new JTextField();
		txtIdOrigen.setColumns(10);
		txtIdOrigen.setBounds(219, 78, 86, 20);
		contentPane.add(txtIdOrigen);
		
		txtFechaVenta = new JTextField();
		txtFechaVenta.setColumns(10);
		txtFechaVenta.setBounds(219, 101, 86, 20);
		contentPane.add(txtFechaVenta);
		
		txtHoraVenta = new JTextField();
		txtHoraVenta.setColumns(10);
		txtHoraVenta.setBounds(219, 126, 86, 20);
		contentPane.add(txtHoraVenta);
		
		txtHoraSalida = new JTextField();
		txtHoraSalida.setColumns(10);
		txtHoraSalida.setBounds(219, 151, 86, 20);
		contentPane.add(txtHoraSalida);
		
		txtFechaEjecucion = new JTextField();
		txtFechaEjecucion.setColumns(10);
		txtFechaEjecucion.setBounds(219, 176, 86, 20);
		contentPane.add(txtFechaEjecucion);
		
		txtObservacion = new JTextField();
		txtObservacion.setColumns(10);
		txtObservacion.setBounds(219, 201, 86, 20);
		contentPane.add(txtObservacion);
		
		txtFkClientes = new JTextField();
		txtFkClientes.setColumns(10);
		txtFkClientes.setBounds(219, 226, 86, 20);
		contentPane.add(txtFkClientes);
		
		txtFkPromotor = new JTextField();
		txtFkPromotor.setColumns(10);
		txtFkPromotor.setBounds(219, 249, 86, 20);
		contentPane.add(txtFkPromotor);
		
		txtFkAgencia = new JTextField();
		txtFkAgencia.setColumns(10);
		txtFkAgencia.setBounds(219, 274, 86, 20);
		contentPane.add(txtFkAgencia);
		
		txtFkMedio = new JTextField();
		txtFkMedio.setColumns(10);
		txtFkMedio.setBounds(219, 299, 86, 20);
		contentPane.add(txtFkMedio);
		
		txtPrecios = new JTextField();
		txtPrecios.setColumns(10);
		txtPrecios.setBounds(219, 324, 86, 20);
		contentPane.add(txtPrecios);
		
		txtFkMatricula = new JTextField();
		txtFkMatricula.setColumns(10);
		txtFkMatricula.setBounds(219, 352, 86, 20);
		contentPane.add(txtFkMatricula);
		
		JButton btnNewButton = new JButton("Registrar");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			
				Paquetesclass crear = new Paquetesclass();
				
				crear.create(Integer.parseInt(txtIdDestino.getText()),Integer.parseInt(txtIdOrigen.getText()),txtFechaVenta.getText(),txtHoraVenta.getText(),txtHoraSalida.getText(),txtFechaEjecucion.getText(),txtObservacion.getText(),Integer.parseInt(txtFkClientes.getText()),Integer.parseInt(txtFkPromotor.getText()),Integer.parseInt(txtFkAgencia.getText()),Integer.parseInt(txtFkMedio.getText()),txtPrecios.getText(),txtFkMatricula.getText());
			
				
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnNewButton.setBounds(328, 76, 117, 23);
		contentPane.add(btnNewButton);
		
		btnEliminar = new JButton("Eliminar");
		btnEliminar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				Paquetesclass Dl = new Paquetesclass();
				Dl.delete(Integer.parseInt(txtIdpaquetes.getText()));
				txtIdpaquetes.setText("");
			}
		});
		btnEliminar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnEliminar.setBounds(328, 103, 117, 23);
		contentPane.add(btnEliminar);
		
		btnActualizar = new JButton("Actualizar");
		btnActualizar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				Paquetesclass Up = new Paquetesclass();
				Up.update(Integer.parseInt(txtIdpaquetes.getText()),Integer.parseInt(txtIdDestino.getText()),Integer.parseInt(txtIdOrigen.getText()),txtFechaVenta.getText(),txtHoraVenta.getText(),txtHoraSalida.getText(),txtFechaEjecucion.getText(),txtObservacion.getText(),Integer.parseInt(txtFkClientes.getText()),Integer.parseInt(txtFkPromotor.getText()),Integer.parseInt(txtFkAgencia.getText()),Integer.parseInt(txtFkMedio.getText()),txtPrecios.getText(),txtFkMatricula.getText());
			
			}
		});
		btnActualizar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnActualizar.setBounds(328, 128, 117, 23);
		contentPane.add(btnActualizar);
		
		btnMostrar = new JButton("Mostrar");
		btnMostrar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				Paquetesclass Ro = new Paquetesclass();
				Ro.readOne(Integer.parseInt(txtIdpaquetes.getText()), txtIdDestino, txtIdOrigen, txtFechaVenta, txtHoraVenta, txtHoraSalida, txtFechaEjecucion, txtObservacion, txtFkClientes, txtFkPromotor, txtFkAgencia, txtFkMedio, txtPrecios, txtFkMatricula);
				
			}
		});
		btnMostrar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnMostrar.setBounds(328, 153, 117, 23);
		contentPane.add(btnMostrar);
	}

}
