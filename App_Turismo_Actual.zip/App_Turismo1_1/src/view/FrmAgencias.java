package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.Agenciasclass;

import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class FrmAgencias extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtNombre;
	private JTextField txtDireccion;
	private JTextField txtTelefono;
	private JTextField txtCorreo;
	private JTextField txtweb;
	private JTextField txtFkCompanias;
	private JTextField txtIdAgencias;
	private JButton btnEliminar;
	private JButton btnActualizar;
	private JButton btnMostrar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmAgencias frame = new FrmAgencias();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmAgencias() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 479, 292);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtNombre = new JTextField();
		txtNombre.setBounds(221, 64, 86, 20);
		contentPane.add(txtNombre);
		txtNombre.setColumns(10);
		
		txtDireccion = new JTextField();
		txtDireccion.setColumns(10);
		txtDireccion.setBounds(221, 95, 86, 20);
		contentPane.add(txtDireccion);
		
		txtTelefono = new JTextField();
		txtTelefono.setColumns(10);
		txtTelefono.setBounds(221, 126, 86, 20);
		contentPane.add(txtTelefono);
		
		txtCorreo = new JTextField();
		txtCorreo.setColumns(10);
		txtCorreo.setBounds(221, 157, 86, 20);
		contentPane.add(txtCorreo);
		
		txtweb = new JTextField();
		txtweb.setColumns(10);
		txtweb.setBounds(221, 181, 86, 20);
		contentPane.add(txtweb);
		
		txtFkCompanias = new JTextField();
		txtFkCompanias.setColumns(10);
		txtFkCompanias.setBounds(221, 206, 86, 20);
		contentPane.add(txtFkCompanias);
		
		JLabel lblNewLabel = new JLabel("Nombre");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel.setBounds(109, 64, 82, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblDireccin = new JLabel("Dirección");
		lblDireccin.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblDireccin.setBounds(109, 95, 82, 14);
		contentPane.add(lblDireccin);
		
		JLabel lblNewLabel_2 = new JLabel("Teléfono");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_2.setBounds(109, 126, 82, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Correo");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_3.setBounds(109, 157, 82, 14);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Web");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_4.setBounds(109, 181, 82, 14);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("FkCompañias");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_5.setBounds(110, 206, 95, 14);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblIdAgencias = new JLabel("Id Agencias");
		lblIdAgencias.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblIdAgencias.setBounds(109, 36, 82, 14);
		contentPane.add(lblIdAgencias);
		
		txtIdAgencias = new JTextField();
		txtIdAgencias.setColumns(10);
		txtIdAgencias.setBounds(221, 34, 86, 20);
		contentPane.add(txtIdAgencias);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				Agenciasclass crear = new Agenciasclass();
				
				crear.create(txtNombre.getText(),txtDireccion.getText(),txtTelefono.getText(),txtCorreo.getText(),txtweb.getText(),Integer.parseInt(txtFkCompanias.getText()));
				
				
			}
		});
		btnRegistrar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnRegistrar.setBounds(317, 60, 113, 23);
		contentPane.add(btnRegistrar);
		
		btnEliminar = new JButton("Eliminar");
		btnEliminar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Agenciasclass Dl = new Agenciasclass();
				Dl.delete(Integer.parseInt(txtIdAgencias.getText()));
				txtIdAgencias.setText("");
			}
		});
		btnEliminar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnEliminar.setBounds(317, 91, 113, 23);
		contentPane.add(btnEliminar);
		
		btnActualizar = new JButton("Actualizar");
		btnActualizar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				Agenciasclass Up = new Agenciasclass();
				Up.update(Integer.parseInt(txtIdAgencias.getText()), txtNombre.getText(), txtDireccion.getText(), txtTelefono.getText(),txtCorreo.getText(),txtweb.getText(),Integer.parseInt(txtFkCompanias.getText()));
			}
		});
		btnActualizar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnActualizar.setBounds(317, 124, 113, 23);
		contentPane.add(btnActualizar);
		
		btnMostrar = new JButton("Mostrar");
		btnMostrar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Agenciasclass Ro = new Agenciasclass();
				Ro.readOne(Integer.parseInt(txtIdAgencias.getText()), txtNombre, txtDireccion, txtTelefono, txtCorreo, txtweb, txtFkCompanias);
				
			}
		});
		btnMostrar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnMostrar.setBounds(317, 156, 113, 23);
		contentPane.add(btnMostrar);
	}
}

