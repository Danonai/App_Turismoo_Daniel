package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import view.FrmClientes;
public class FrmPanelControl extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmPanelControl frame = new FrmPanelControl();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmPanelControl() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 602, 427);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Operadores");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				FrmOperadores prm = new FrmOperadores();
				prm.setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnNewButton.setBounds(28, 68, 157, 42);
		contentPane.add(btnNewButton);
		
		JButton btnPromotor = new JButton("Promotores");
		btnPromotor.addMouseListener(new MouseAdapter() {
			@Override 
			public void mouseClicked(MouseEvent e) {
				FrmPromotores Abrir = new FrmPromotores();
				Abrir.setVisible(true);
			}
		});
		btnPromotor.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnPromotor.setBounds(234, 23, 111, 42);
		contentPane.add(btnPromotor);
		
		JButton btnVehiculos = new JButton("Vehiculos");
		btnVehiculos.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				FrmVehiculos Prm = new 	FrmVehiculos ();
				Prm.setVisible(true);
			}
		});
		btnVehiculos.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnVehiculos.setBounds(28, 131, 157, 44);
		contentPane.add(btnVehiculos);
		
		JButton btnMedios = new JButton("Tipo Transporte");
		btnMedios.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				FrmTiposTransportes Prm = new 	FrmTiposTransportes ();
			   Prm.setVisible(true);
			}
		});
		btnMedios.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnMedios.setBounds(399, 87, 157, 42);
		contentPane.add(btnMedios);
		
		JButton btnClientes = new JButton("Clientes");
		btnClientes.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				FrmClientes prm = new FrmClientes();
				prm.setVisible(true);
				
			}
		});
		btnClientes.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnClientes.setBounds(234, 87, 111, 42);
		contentPane.add(btnClientes);
		
		JButton btnAgencias = new JButton("Agencias");
		btnAgencias.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				FrmAgencias prm = new FrmAgencias();
				prm.setVisible(true);
				
			}
		});
		btnAgencias.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnAgencias.setBounds(234, 234, 111, 42);
		contentPane.add(btnAgencias);
		
		JButton btnPaquetes = new JButton("Paquetes");
		btnPaquetes.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				FrmPaquetes prm = new FrmPaquetes();
				prm.setVisible(true);
			}
		});
		btnPaquetes.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnPaquetes.setBounds(234, 321, 111, 42);
		contentPane.add(btnPaquetes);
		
		JButton btnTiposDeTransporte = new JButton("Medios");
		btnTiposDeTransporte.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				FrmMedios Prm = new 	FrmMedios ();
				Prm.setVisible(true);
			}
		});
		btnTiposDeTransporte.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnTiposDeTransporte.setBounds(33, 200, 152, 42);
		contentPane.add(btnTiposDeTransporte);
		
		JButton btnTiposDeMedios_1 = new JButton("Tipos de medios");
		btnTiposDeMedios_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				FrmTiposMedios Prm = new 	FrmTiposMedios ();
				Prm.setVisible(true);
			}
		});
		btnTiposDeMedios_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnTiposDeMedios_1.setBounds(399, 143, 152, 44);
		contentPane.add(btnTiposDeMedios_1);
		
		JButton btnDestino = new JButton("Destino");
		btnDestino.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				FrmDestino Prm = new 	FrmDestino ();
				Prm.setVisible(true);
				
			}
		});
		btnDestino.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnDestino.setBounds(399, 200, 153, 42);
		contentPane.add(btnDestino);
		
		JButton btnOrigen = new JButton("Origen");
		btnOrigen.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				FrmOrigen Prm = new 	FrmOrigen ();
				Prm.setVisible(true);
			}
		});
		btnOrigen.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnOrigen.setBounds(403, 253, 153, 42);
		contentPane.add(btnOrigen);
		
		JButton btnCompaias = new JButton("Compañias");
		btnCompaias.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				FrmCompanias prm = new FrmCompanias();
				prm.setVisible(true);
				
			}
		});
		btnCompaias.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnCompaias.setBounds(234, 166, 111, 42);
		contentPane.add(btnCompaias);
		
		
	}
	
	

}
