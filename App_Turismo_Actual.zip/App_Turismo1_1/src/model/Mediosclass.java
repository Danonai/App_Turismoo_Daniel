package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

import controller.Conexion;

public class Mediosclass {
	
	int idmedios;
	String nombre ; 
	String observacion;
	int fktiposmedios;
	
	public int getIdmedios() {
		return idmedios;
	}

	public void setIdmedios(int idmedios) {
		this.idmedios = idmedios;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getObservacion() {
		return observacion;
	}

	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}

	public int getFktiposmedios() {
		return fktiposmedios;
	}

	public void setFktiposmedios(int fktiposmedios) {
		this.fktiposmedios = fktiposmedios;
	}

	public Mediosclass() {
		super();
	}

	public Mediosclass(int idmedios, String nombre, String observacion, int fktiposmedios) {
		super();
		this.idmedios = idmedios;
		this.nombre = nombre;
		this.observacion = observacion;
		this.fktiposmedios = fktiposmedios;
	}
	
	
	Conexion conector = new Conexion();

	public void create(String nombre, String observacion, int fktiposmedios) {
		Connection dbConnection = null;
		PreparedStatement pst = null;

		String crear = "Insert Into tblmedios ( nombre ,observacion, fktiposmedios) values (?,?,?)";

		try {
			dbConnection = conector.conectarBD();
			pst = dbConnection.prepareStatement(crear);

			pst.setString(1, nombre);
			pst.setString(2, observacion);
			pst.setInt(3, fktiposmedios);
			pst.executeUpdate();

			JOptionPane.showMessageDialog(null, "Registro con Exito");

		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}

	}
	
	Conexion conector1 = new Conexion();

	public void create(String matricula, String marca, int puestos, String modelo, String numeromotor,
			String categoria, int fktipotranspo) {
		Connection dbConnection = null;
		PreparedStatement pst = null;

		String crear = "Insert Into tblpaquetes ( matricula, marca, puestos, modelo,  numeromotor, categoria,  fktipotranspo) values (?,?,?,?,?,?,?)";

		try {
			dbConnection = conector.conectarBD();
			pst = dbConnection.prepareStatement(crear);

			pst.setString(1, matricula);
			pst.setString(2, marca);
			pst.setInt(3, puestos);
			pst.setString(4, modelo);
			pst.setString(5, numeromotor);
			pst.setString(6, categoria);
			pst.setInt(7, fktipotranspo);
			pst.executeUpdate();

			JOptionPane.showMessageDialog(null, "Registro con Exito");

		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}

	}
	
	public void delete(int idmedios) {
		Connection dbConnection = null;
		PreparedStatement pst = null;
		
		String script = "DELETE FROM tblmedios WHERE  idmedios = ?" ;
		
		try {
			dbConnection = conector.conectarBD(); //Abrir la conexion
			pst = dbConnection.prepareStatement(script); //Abrir el buffer
			
			//Parametrizar el campo
			pst.setInt(1, idmedios);
			
			int resp = JOptionPane.showConfirmDialog(null, "Desea eliminar el registro No."+ idmedios+ " ?" );
			
			if (resp == JOptionPane.YES_OPTION) {
				pst.executeUpdate();
				JOptionPane.showMessageDialog(null, "Registro No. "+ idmedios+" Eliminado");
			}
			
			
		}catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
	
	public void update(int idmedios, String nombre, String observacion, int fktiposmedios) {
	    Connection dbConnection = null;
	    PreparedStatement pst = null;

	    String script = "UPDATE tblmedios SET nombre = ?, observacion = ?, fktiposmedios = ? WHERE idmedios = ?;";

	    try {
	        dbConnection = conector.conectarBD(); // abrir la conexión
	        pst = dbConnection.prepareStatement(script); // preparar el statement

	        // parametrizar los campos
	        pst.setString(1, nombre);
	        pst.setString(2, observacion);
	        pst.setInt(3, fktiposmedios);
	        pst.setInt(4, idmedios);

	        // confirmar la operación
	        int resp = JOptionPane.showConfirmDialog(null, "¿Desea actualizar esta fila?");

	        if (resp == JOptionPane.OK_OPTION) {
	            pst.executeUpdate();
	            JOptionPane.showMessageDialog(null, "Fila actualizada");
	        }

	    } catch (SQLException e) {
	        System.out.println(e.getMessage());
	    }
	}
	
	public void readOne(int idmedios, JTextField nombre, JTextField observacion, JTextField fktipomedios) {

	    Connection dbConnection = null;
	    PreparedStatement pst = null;

	    String script = "SELECT * FROM tblmedios WHERE idmedios = ?;";

	    try {
	        dbConnection = conector.conectarBD(); // abrir conexión
	        pst = dbConnection.prepareStatement(script); // preparar la consulta

	        pst.setInt(1, idmedios); // establecer parámetro

	        ResultSet rs = pst.executeQuery(); // ejecutar consulta

	        while (rs.next()) {
	            nombre.setText(rs.getString(2));
	            observacion.setText(rs.getString(3));
	            fktipomedios.setText(rs.getString(4));
	        }

	    } catch (SQLException e) {
	        System.out.println(e.getMessage());
	    }
	}



}
