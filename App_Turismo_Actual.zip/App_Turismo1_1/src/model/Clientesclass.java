package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

import controller.Conexion;

public class Clientesclass {
	int idclientes;
	int tipodocumento;
	int documento;
	String nombres;
	String apellidos;
	String eps;
	String fechanacimiento;
	String correo;
	String estadocivil;
	String telefono;
	String direccion;
	String alergias;
	

	public Clientesclass(int idclientes, int tipodocumento, int documento, String nombres, String apellidos, String eps,
			String fechanacimiento, String correo, String estadocivil, String telefono, String direccion,
			String alergias) {
		super();
		this.idclientes = idclientes;
		this.tipodocumento = tipodocumento;
		this.documento = documento;
		this.nombres = nombres;
		this.apellidos = apellidos;
		this.eps = eps;
		this.fechanacimiento = fechanacimiento;
		this.correo = correo;
		this.estadocivil = estadocivil;
		this.telefono = telefono;
		this.direccion = direccion;
		this.alergias = alergias;
	}

	public int getIdclientes() {
		return idclientes;
	}

	public void setIdclientes(int idclientes) {
		this.idclientes = idclientes;
	}

	public Clientesclass() {
		super();
	}

	public int getTipodocumento() {
		return tipodocumento;
	}

	public void setTipodocumento(int tipodocumento) {
		this.tipodocumento = tipodocumento;
	}

	public int getDocumento() {
		return documento;
	}

	public void setDocumento(int documento) {
		this.documento = documento;
	}

	public String getNombres() {
		return nombres;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getEps() {
		return eps;
	}

	public void setEps(String eps) {
		this.eps = eps;
	}

	public String getFechanacimiento() {
		return fechanacimiento;
	}

	public void setFechanacimiento(String fechanacimiento) {
		this.fechanacimiento = fechanacimiento;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getEstadocivil() {
		return estadocivil;
	}

	public void setEstadocivil(String estadocivil) {
		this.estadocivil = estadocivil;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getAlergias() {
		return alergias;
	}

	public void setAlergias(String alergias) {
		this.alergias = alergias;
	}

	Conexion conector = new Conexion();

	public void create(int tipodocumento, int documento, String nombres, String apellidos, String eps,
			String fechanacimiento, String correo, String estadocivil, String telefono, String direccion,
			String alergias) {
		Connection dbConnection = null;
		PreparedStatement pst = null;

		String script = "Insert Into tblclientes ( tipodocumento,  documento, nombres, apellidos, eps, fechanacimiento, correo, estadocivil, telefono, direccion,alergias) values (?,?,?,?,?,?,?,?,?,?,?)";

		try {
			dbConnection = conector.conectarBD();
			pst = dbConnection.prepareStatement(script);

			pst.setInt(1, tipodocumento);
			pst.setInt(2, documento);
			pst.setString(3, nombres);
			pst.setString(4, apellidos);
			pst.setString(5, eps);
			pst.setString(6, fechanacimiento);
			pst.setString(7, correo);
			pst.setString(8, estadocivil);
			pst.setString(9, telefono);
			pst.setString(10, direccion);
			pst.setString(11, alergias);

			pst.executeUpdate();

			JOptionPane.showMessageDialog(null, "Registro con Exito");

		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}

	}

	public void delete(int idclientes) {
		Connection dbConnection = null;
		PreparedStatement pst = null;

		String script = "DELETE FROM tblclientes WHERE idclientes = ?";
		try {
			dbConnection = conector.conectarBD(); // Abrir la conexion
			pst = dbConnection.prepareStatement(script); // Abrir el buffer

			// Parametrizar el campo
			pst.setInt(1, idclientes);

			int resp = JOptionPane.showConfirmDialog(null, "Desea eliminar el registro No." + idclientes + " ?");

			if (resp == JOptionPane.YES_OPTION) {
				pst.executeUpdate();
				JOptionPane.showMessageDialog(null, "Registro No. " + idclientes + " Eliminado");
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

	public void update(int idclientes, int tipodocumento, int documento, String nombres, String apellidos, String eps,
			String fechanacimiento, String correo, String estadocivil, String telefono, String direccion,
			String alergias) {

		Connection dbConnection = null;
		PreparedStatement pst = null; // preparar la trx

		String script = "UPDATE tblclientes SET  tipodocumento = ?,  documento = ?, nombres = ?, apellidos = ?,  eps = ?,  fechanacimiento = ?, correo = ?, estadocivil = ?,telefono = ?, direccion = ?, alergias = ? WHERE idclientes = ?;";

		try {
			dbConnection = conector.conectarBD(); // abrir la conexion
			pst = dbConnection.prepareStatement(script); // abrir el buffer

			// parametrizar el campo

			pst.setInt(12, idclientes);
			pst.setInt(1, tipodocumento);
			pst.setInt(2, documento);
			pst.setString(3, nombres);
			pst.setString(4, apellidos);
			pst.setString(5, eps);
			pst.setString(6, fechanacimiento);
			pst.setString(7, correo);
			pst.setString(8, estadocivil);
			pst.setString(9, telefono);
			pst.setString(10, direccion);
			pst.setString(11, alergias);

			// confirmar la operacion
			int resp = JOptionPane.showConfirmDialog(null, "¿desea actualizar esta fila?");

			if (resp == JOptionPane.OK_OPTION) {
				pst.executeUpdate();
				JOptionPane.showConfirmDialog(null, "fila actualizada");
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

	public void readOne(int idclientes, JTextField tipodocumento, JTextField numerodocumento, JTextField nombres,
			JTextField apellidos, JTextField eps, JTextField fechanacimiento, JTextField correo,
			JTextField estadocivil, JTextField telefono, JTextField direccion,JTextField alergias) {

		Connection dbConnection = null;
		PreparedStatement pst = null;

		String script = "SELECT * FROM tblclientes WHERE idclientes = ?;";

		try {
			dbConnection = conector.conectarBD(); // abrir la conexión
			pst = dbConnection.prepareStatement(script); // preparar la sentencia

			pst.setInt(1, idclientes); // parametrizar el WHERE

			ResultSet rs = pst.executeQuery(); // ejecutar consulta

			while (rs.next()) {
				tipodocumento.setText(rs.getString(2));
				numerodocumento.setText(rs.getString(3));
				nombres.setText(rs.getString(4));
				apellidos.setText(rs.getString(5));
				eps.setText(rs.getString(6));
				fechanacimiento.setText(rs.getString(7));
				correo.setText(rs.getString(8));
				estadocivil.setText(rs.getString(9));
				telefono.setText(rs.getString(10));
				direccion.setText(rs.getString(11));
				alergias.setText(rs.getString(12));
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

}
