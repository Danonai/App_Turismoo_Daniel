package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

import controller.Conexion;

public class Agenciasclass {
	int idagencias;
	String nombre;
	String direccion;
	String telefono;
	String correo;
	String web;
	int fkcompanias;

	public Agenciasclass(int idagencias) {
		super();
		this.idagencias = idagencias;
	}

	public Agenciasclass(String nombre, String direccion, String telefono, String correo, String web, int fkcompanias,
			Conexion conector) {
		super();
		this.nombre = nombre;
		this.direccion = direccion;
		this.telefono = telefono;
		this.correo = correo;
		this.web = web;
		this.fkcompanias = fkcompanias;
		this.conector = conector;
	}

	public int getIdagencias() {
		return idagencias;
	}

	public void setIdagencias(int idagencias) {
		this.idagencias = idagencias;
	}

	public Agenciasclass() {
		super();
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getWeb() {
		return web;
	}

	public void setWeb(String web) {
		this.web = web;
	}

	public int getFkcompanias() {
		return fkcompanias;
	}

	public void setFkcompanias(int fkcompanias) {
		this.fkcompanias = fkcompanias;
	}

	public Conexion getConector() {
		return conector;
	}

	public void setConector(Conexion conector) {
		this.conector = conector;
	}

	Conexion conector = new Conexion();

	public void create(String nombre, String direccion, String telefono, String correo, String web, int fkcompanias) {
		Connection dbConnection = null;
		PreparedStatement pst = null;

		String crear = "Insert Into tblagencias ( nombre, direccion, telefono, correo, web, fkcompanias) values (?,?,?,?,?,?)";

		try {
			dbConnection = conector.conectarBD();
			pst = dbConnection.prepareStatement(crear);

			pst.setString(1, nombre);
			pst.setString(2, direccion);
			pst.setString(3, telefono);
			pst.setString(4, correo);
			pst.setString(5, web);
			pst.setInt(6, fkcompanias);

			pst.executeUpdate();

			JOptionPane.showMessageDialog(null, "Registro con Exito");

		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}

	}

	public void delete(int idagencias) {
		Connection dbConnection = null;
		PreparedStatement pst = null;

		String script = "DELETE FROM tblagencias WHERE idagencias = ?";

		try {
			dbConnection = conector.conectarBD(); // Abrir la conexion
			pst = dbConnection.prepareStatement(script); // Abrir el buffer

			// Parametrizar el campo
			pst.setInt(1, idagencias);

			int resp = JOptionPane.showConfirmDialog(null, "Desea eliminar el registro No." + idagencias + " ?");

			if (resp == JOptionPane.YES_OPTION) {
				pst.executeUpdate();
				JOptionPane.showMessageDialog(null, "Registro No. " + idagencias + " Eliminado");
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

	public void update(int idagencias, String nombre, String direccion, String telefono, String correo, String web,
			int fkcompanias) {

		Connection dbConnection = null;
		PreparedStatement pst = null; // preparar la trx

		String script = "UPDATE tblagencias SET  nombre = ? , direccion = ?, telefono = ? , correo = ?, web = ?, fkcompanias = ? WHERE idagencias = ?;";

		try {
			dbConnection = conector.conectarBD(); // abrir la conexion
			pst = dbConnection.prepareStatement(script); // abrir el buffer

			// parametrizar el campo

			pst.setInt(7, idagencias);
			pst.setString(1, nombre);
			pst.setString(2, direccion);
			pst.setString(3, telefono);
			pst.setString(4, correo);
			pst.setString(5, web);
			pst.setInt(6, fkcompanias);

			// confirmar la operacion
			int resp = JOptionPane.showConfirmDialog(null, "¿desea actualizar esta fila?");

			if (resp == JOptionPane.OK_OPTION) {
				pst.executeUpdate();
				JOptionPane.showConfirmDialog(null, "fila actualizada");
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

	public void readOne(int idagencias, JTextField nombre, JTextField direccion, JTextField telefono, JTextField correo,
			JTextField web, JTextField fkcompanias) {
		
		Connection dbConnection = null;
		PreparedStatement pst = null;
		
		String script = "SELECT * FROM tblagencias WHERE idagencias = ?;";

		try {
			dbConnection = conector.conectarBD(); // abrir conexión
			pst = dbConnection.prepareStatement(script); // preparar consulta

			pst.setInt(1, idagencias); // establecer parámetro

			ResultSet rs = pst.executeQuery(); // ejecutar consulta

			while (rs.next()) {
				nombre.setText(rs.getString(2));
				direccion.setText(rs.getString(3));
				telefono.setText(rs.getString(4));
				correo.setText(rs.getString(5));
				 web.setText(rs.getString(6));
				 fkcompanias.setText(rs.getString(7));
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

	}

