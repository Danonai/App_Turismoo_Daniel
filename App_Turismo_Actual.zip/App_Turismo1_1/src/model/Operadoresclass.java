package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

import controller.Conexion;

public class Operadoresclass {

	int idoperadores;
	int tipodocumento;
	int documento;
	String nombres;
	String apellidos;
	String direccion;
	String correo;
	String telefono;
	String fkmatricula;

	public Operadoresclass(int idoperadores) {
		super();
		this.idoperadores = idoperadores;

	}

	public Operadoresclass() {
		super();
	}

	public Operadoresclass(int idoperadores, int tipodocumento, int documento, String nombres, String apellidos,
			String direccion, String correo, String telefono, String fkmatricula) {
		super();
		this.tipodocumento = tipodocumento;
		this.documento = documento;
		this.nombres = nombres;
		this.apellidos = apellidos;
		this.direccion = direccion;
		this.correo = correo;
		this.telefono = telefono;
		this.fkmatricula = fkmatricula;
	}

	public int getIdoperadores() {
		return idoperadores;
	}

	public void setIdoperadores(int idoperadores) {
		this.idoperadores = idoperadores;
	}

	public int getTipodocumento() {
		return tipodocumento;
	}

	public void setTipodocumento(int tipodocumento) {
		this.tipodocumento = tipodocumento;
	}

	public int getDocumento() {
		return documento;
	}

	public void setDocumento(int documento) {
		this.documento = documento;
	}

	public String getNombres() {
		return nombres;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getFkmatricula() {
		return fkmatricula;
	}

	public void setFkmatricula(String fkmatricula) {
		this.fkmatricula = fkmatricula;
	}

	Conexion conector = new Conexion();

	public void create(int tipodocumento, int documento, String nombres, String apellidos, String direccion,
			String correo, String telefono, String fkmatricula) {
		Connection dbConnection = null;
		PreparedStatement pst = null;

		String script = "Insert Into tbloperadores (tipodocumento,documento,nombres, apellidos,direccion, correo,telefono,fkmatricula) values (?,?,?,?,?,?,?,?)";

		try {
			dbConnection = conector.conectarBD();
			pst = dbConnection.prepareStatement(script);

			pst.setInt(1, tipodocumento);
			pst.setInt(2, documento);
			pst.setString(3, nombres);
			pst.setString(4, apellidos);
			pst.setString(5, direccion);
			pst.setString(6, correo);
			pst.setString(7, telefono);
			pst.setString(8, fkmatricula);
			pst.executeUpdate();

			JOptionPane.showConfirmDialog(null, "Registro con Exito");

		} catch (Exception e) {

		}

	}

	public void delete(int idoperadores) {
		Connection dbConnection = null;
		PreparedStatement pst = null;

		String script = "DELETE FROM tbloperadores WHERE idoperadores = ?";

		try {
			dbConnection = conector.conectarBD(); // Abrir la conexion
			pst = dbConnection.prepareStatement(script); // Abrir el buffer

			// Parametrizar el campo
			pst.setInt(1, idoperadores);

			int resp = JOptionPane.showConfirmDialog(null, "Desea eliminar el registro No." + idoperadores + " ?");

			if (resp == JOptionPane.YES_OPTION) {
				pst.executeUpdate();
				JOptionPane.showMessageDialog(null, "Registro No. " + idoperadores + " Eliminado");
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

	public void update(int idoperadores, int tipodocumento, int documento, String nombres, String apellidos,
			String direccion, String correo, String telefono, String fkmatricula) {

		Connection dbConnection = null;
		PreparedStatement pst = null; // preparar la trx

		String script = "UPDATE tbloperadores SET tipodocumento = ?, documento = ?, nombres = ?,  apellidos = ?,\r\n"
				+ "			 direccion = ?, correo = ?, fechanacimiento= ?, telefono = ?, fkmatricula = ? WHERE idoperadores = ?;";

		try {
			dbConnection = conector.conectarBD(); // abrir la conexion
			pst = dbConnection.prepareStatement(script); // abrir el buffer

			// parametrizar el campo

			pst.setInt(9, idoperadores);
			pst.setInt(1, tipodocumento);
			pst.setInt(2, documento);
			pst.setString(3, nombres);
			pst.setString(4, apellidos);
			pst.setString(5, direccion);
			pst.setString(6, correo);
			pst.setString(7, telefono);
			pst.setString(8, fkmatricula);

			// confirmar la operacion
			int resp = JOptionPane.showConfirmDialog(null, "¿desea actualizar esta fila?");

			if (resp == JOptionPane.OK_OPTION) {
				pst.executeUpdate();
				JOptionPane.showConfirmDialog(null, "fila actualizada");
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

	public void readOne(int idoperadores, JTextField tipodocumento, JTextField documento, JTextField nombre,
			JTextField apellido, JTextField direccion, JTextField correo, JTextField telefono, JTextField fkmatricula) {

		Connection dbConnection = null;
		PreparedStatement pst = null;

		String script = "SELECT * FROM tbloperadores WHERE idoperadores = ?;";

		try {
			dbConnection = conector.conectarBD(); // abrir la conexión
			pst = dbConnection.prepareStatement(script); // preparar la consulta SQL

			pst.setInt(1, idoperadores); // asignar el valor al parámetro

			ResultSet rs = pst.executeQuery(); // ejecutar la consulta

			while (rs.next()) {
				tipodocumento.setText(rs.getString(2));
				documento.setText(rs.getString(3));
				nombre.setText(rs.getString(4));
				apellido.setText(rs.getString(5));
				direccion.setText(rs.getString(6));
				correo.setText(rs.getString(7));
				telefono.setText(rs.getString(8));
				fkmatricula.setText(rs.getString(9));
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

}
