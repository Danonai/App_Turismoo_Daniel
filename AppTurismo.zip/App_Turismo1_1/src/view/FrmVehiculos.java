package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.Vehiculosclass;

import javax.swing.JLabel;
import javax.swing.JTextField;

import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FrmVehiculos extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtMatricula;
	private JTextField txtMarca;
	private JTextField txtPuestos;
	private JTextField txtModelo;
	private JTextField txtNumeroMotor;
	private JTextField txtCategoria;
	private JTextField txtFkTipoTrans;
	private JButton btnEliminar;
	private JButton btnActualizar;
	private JButton btnMostrar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmVehiculos frame = new FrmVehiculos();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmVehiculos() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 433, 340);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Matricula");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel.setBounds(44, 27, 158, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Marca");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_1.setBounds(44, 56, 158, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Puestos");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_2.setBounds(44, 91, 158, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Modelo");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_3.setBounds(44, 124, 158, 14);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Numero del Motor");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_4.setBounds(44, 156, 158, 14);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Categoría");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_5.setBounds(44, 192, 158, 14);
		contentPane.add(lblNewLabel_5);
		
		txtMatricula = new JTextField();
		txtMatricula.setBounds(206, 23, 86, 20);
		contentPane.add(txtMatricula);
		txtMatricula.setColumns(10);
		
		txtMarca = new JTextField();
		txtMarca.setColumns(10);
		txtMarca.setBounds(206, 55, 86, 20);
		contentPane.add(txtMarca);
		
		txtPuestos = new JTextField();
		txtPuestos.setColumns(10);
		txtPuestos.setBounds(206, 87, 86, 20);
		contentPane.add(txtPuestos);
		
		txtModelo = new JTextField();
		txtModelo.setColumns(10);
		txtModelo.setBounds(206, 120, 86, 20);
		contentPane.add(txtModelo);
		
		txtNumeroMotor = new JTextField();
		txtNumeroMotor.setColumns(10);
		txtNumeroMotor.setBounds(206, 152, 86, 20);
		contentPane.add(txtNumeroMotor);
		
		txtCategoria = new JTextField();
		txtCategoria.setColumns(10);
		txtCategoria.setBounds(206, 188, 86, 20);
		contentPane.add(txtCategoria);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnRegistrar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				Vehiculosclass cr = new Vehiculosclass();
				
				cr.create(txtMatricula.getText(),txtMarca.getText(),Integer.parseInt(txtPuestos.getText()),txtModelo.getText(),Integer.parseInt(txtNumeroMotor.getText()),txtCategoria.getText(),Integer.parseInt(txtFkTipoTrans.getText()));
			}
		});
		btnRegistrar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnRegistrar.setBounds(300, 52, 104, 23);
		contentPane.add(btnRegistrar);
		
		JLabel lblNewLabel_5_1 = new JLabel("Fk Tipo de Transporte");
		lblNewLabel_5_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_5_1.setBounds(44, 232, 158, 14);
		contentPane.add(lblNewLabel_5_1);
		
		txtFkTipoTrans = new JTextField();
		txtFkTipoTrans.setColumns(10);
		txtFkTipoTrans.setBounds(206, 228, 86, 20);
		contentPane.add(txtFkTipoTrans);
		
		btnEliminar = new JButton("Eliminar");
		btnEliminar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Vehiculosclass Dl = new Vehiculosclass();
				Dl.delete(txtMatricula.getText());
				txtMatricula.setText("");
			}
		});
		btnEliminar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnEliminar.setBounds(302, 87, 102, 23);
		contentPane.add(btnEliminar);
		
		btnActualizar = new JButton("Actualizar");
		btnActualizar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Vehiculosclass Up = new Vehiculosclass();
				Up.update(txtMatricula.getText(),txtMarca.getText(),Integer.parseInt(txtPuestos.getText()),txtModelo.getText(),Integer.parseInt(txtNumeroMotor.getText()),txtCategoria.getText(),Integer.parseInt(txtFkTipoTrans.getText()));
			
				
				
			}
		});
		btnActualizar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnActualizar.setBounds(302, 121, 102, 23);
		contentPane.add(btnActualizar);
		
		btnMostrar = new JButton("Mostrar");
		btnMostrar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Vehiculosclass Ro = new Vehiculosclass();
				Ro.readOne(txtMatricula.getText(), txtMarca, txtPuestos, txtModelo, txtNumeroMotor, txtCategoria, txtFkTipoTrans);
			}
		});
		btnMostrar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnMostrar.setBounds(302, 153, 102, 23);
		contentPane.add(btnMostrar);
	}
}
