package view;

import java.awt.EventQueue;
import model.Promotoresclass;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import model.Promotoresclass;
public class FrmPrincipal extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JPasswordField passwordDocumento;
	private JPasswordField passwordContraseña;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmPrincipal frame = new FrmPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmPrincipal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 407, 216);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("BIENVENIDO");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(118, 11, 140, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblIngresaTuId = new JLabel("Ingresa tu documento");
		lblIngresaTuId.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		lblIngresaTuId.setHorizontalAlignment(SwingConstants.CENTER);
		lblIngresaTuId.setBounds(-9, 53, 241, 14);
		contentPane.add(lblIngresaTuId);
		
		JLabel lblIngresaTuContrasea = new JLabel("Ingresa tu contraseña");
		lblIngresaTuContrasea.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		lblIngresaTuContrasea.setHorizontalAlignment(SwingConstants.CENTER);
		lblIngresaTuContrasea.setBounds(-9, 88, 241, 14);
		contentPane.add(lblIngresaTuContrasea);
		
		passwordDocumento = new JPasswordField();
		passwordDocumento.setBounds(205, 52, 104, 20);
		contentPane.add(passwordDocumento);
		
		passwordContraseña = new JPasswordField();
		passwordContraseña.setBounds(205, 87, 104, 20);
		contentPane.add(passwordContraseña);
		
		JButton btnNewButton = new JButton("INICIAR SESSIÓN");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Promotoresclass Ic = new Promotoresclass ();
				Ic.InicioDeSesion(Integer.parseInt(passwordDocumento.getText()), passwordContraseña.getText());
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		btnNewButton.setBounds(103, 129, 174, 23);
		contentPane.add(btnNewButton);
	}
}
