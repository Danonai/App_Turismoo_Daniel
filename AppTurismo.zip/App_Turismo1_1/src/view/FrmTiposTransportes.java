package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.TiposTransportes;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
public class FrmTiposTransportes extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtNombres;
	private JTextField txtobservacion;
	private JTextField txtIdTipo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmTiposTransportes frame = new FrmTiposTransportes();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmTiposTransportes() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 475, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Nombre");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel.setBounds(73, 108, 68, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Observacion");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_1.setBounds(73, 148, 85, 14);
		contentPane.add(lblNewLabel_1);
		
		txtNombres = new JTextField();
		txtNombres.setBounds(231, 105, 86, 20);
		contentPane.add(txtNombres);
		txtNombres.setColumns(10);
		
		txtobservacion = new JTextField();
		txtobservacion.setColumns(10);
		txtobservacion.setBounds(231, 145, 86, 20);
		contentPane.add(txtobservacion);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				TiposTransportes crear = new TiposTransportes();
				
				crear.create(txtNombres.getText(), txtobservacion.getText());
				
				
				
			}
		});
		btnRegistrar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnRegistrar.setBounds(327, 72, 110, 23);
		contentPane.add(btnRegistrar);
		
		JLabel lblSistemaDeGestin = new JLabel("Sistema de Gestión de Tipo de Transportes");
		lblSistemaDeGestin.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblSistemaDeGestin.setBounds(71, 31, 288, 14);
		contentPane.add(lblSistemaDeGestin);
		
		JLabel lblIdTipoDe = new JLabel("Id Tipo de Transporte");
		lblIdTipoDe.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblIdTipoDe.setBounds(71, 76, 166, 14);
		contentPane.add(lblIdTipoDe);
		
		txtIdTipo = new JTextField();
		txtIdTipo.setColumns(10);
		txtIdTipo.setBounds(231, 74, 86, 20);
		contentPane.add(txtIdTipo);
		
		JButton btnEliminar = new JButton("Eliminar");
		btnEliminar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				TiposTransportes Dl = new TiposTransportes();
				Dl.delete(Integer.parseInt(txtIdTipo.getText()));
				txtIdTipo.setText("");
			}
		});
		btnEliminar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnEliminar.setBounds(327, 104, 110, 23);
		contentPane.add(btnEliminar);
		
		JButton btnActualizar = new JButton("Actualizar");
		btnActualizar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				TiposTransportes Up = new TiposTransportes();
				Up.update(Integer.parseInt(txtIdTipo.getText()),txtNombres.getText(),txtobservacion.getText());
				
				
			}
		});
		btnActualizar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnActualizar.setBounds(327, 138, 110, 23);
		contentPane.add(btnActualizar);
		
		JButton btnMostrar = new JButton("Mostrar");
		btnMostrar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				TiposTransportes Ro = new TiposTransportes();
				Ro.readOne(Integer.parseInt(txtIdTipo.getText()), txtNombres, txtobservacion);
				
			}
		});
		btnMostrar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnMostrar.setBounds(327, 172, 110, 23);
		contentPane.add(btnMostrar);
	}
}
