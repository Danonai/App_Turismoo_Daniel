package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import model.Clientesclass;
import javax.swing.JFormattedTextField;

public class FrmClientes extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtIdClientes;
	private JTextField txtNumeroDocumento;
	private JTextField txtNombres;
	private JTextField txtApellidos;
	private JTextField txtEps;
	private JTextField txtFechaNacimiento;
	private JTextField txtCorreo;
	private JTextField txtEstadoCivil;
	private JTextField txtTelefono;
	private JTextField txtDireccion;
	private JTextField txtAlergias;
	private JTextField txtTipoDocumento;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmClientes frame = new FrmClientes();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmClientes() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 474, 469);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblTipoDeDocumento = new JLabel("Tipo de Documento:");
		lblTipoDeDocumento.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblTipoDeDocumento.setBounds(30, 83, 163, 14);
		contentPane.add(lblTipoDeDocumento);

		JLabel lblNewLabel_2 = new JLabel("ID Clientes");
		lblNewLabel_2.setBounds(59, 110, 82, 0);
		contentPane.add(lblNewLabel_2);

		JLabel lblNmeroDeDocumento = new JLabel("Número de Documento:");
		lblNmeroDeDocumento.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNmeroDeDocumento.setBounds(30, 108, 163, 14);
		contentPane.add(lblNmeroDeDocumento);

		JLabel lblNombres = new JLabel("Nombres:");
		lblNombres.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNombres.setBounds(30, 136, 163, 14);
		contentPane.add(lblNombres);

		JLabel lblApellidos = new JLabel("Apellidos:");
		lblApellidos.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblApellidos.setBounds(30, 161, 163, 14);
		contentPane.add(lblApellidos);

		JLabel lblEps = new JLabel("Eps:");
		lblEps.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblEps.setBounds(30, 191, 163, 14);
		contentPane.add(lblEps);

		JLabel lblFechaDeNacimiento = new JLabel("Fecha de Nacimiento:");
		lblFechaDeNacimiento.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblFechaDeNacimiento.setBounds(30, 216, 163, 14);
		contentPane.add(lblFechaDeNacimiento);

		JLabel lblCorreo = new JLabel("Correo:");
		lblCorreo.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblCorreo.setBounds(30, 241, 163, 14);
		contentPane.add(lblCorreo);

		JLabel lblEstadoCivil = new JLabel("Estado Civil:");
		lblEstadoCivil.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblEstadoCivil.setBounds(30, 266, 163, 14);
		contentPane.add(lblEstadoCivil);

		JLabel lblTelefono = new JLabel("Telefono:");
		lblTelefono.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblTelefono.setBounds(30, 291, 163, 14);
		contentPane.add(lblTelefono);

		JLabel lblDireccin = new JLabel("Dirección:");
		lblDireccin.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblDireccin.setBounds(30, 316, 163, 14);
		contentPane.add(lblDireccin);

		JLabel lblAlergas = new JLabel("Alergias:");
		lblAlergas.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblAlergas.setBounds(30, 341, 163, 14);
		contentPane.add(lblAlergas);

		txtIdClientes = new JTextField();
		txtIdClientes.setColumns(10);
		txtIdClientes.setBounds(194, 51, 86, 20);
		contentPane.add(txtIdClientes);

		txtNumeroDocumento = new JTextField();
		txtNumeroDocumento.setColumns(10);
		txtNumeroDocumento.setBounds(196, 106, 86, 20);
		contentPane.add(txtNumeroDocumento);

		txtNombres = new JTextField();
		txtNombres.setColumns(10);
		txtNombres.setBounds(196, 134, 86, 20);
		contentPane.add(txtNombres);

		txtApellidos = new JTextField();
		txtApellidos.setColumns(10);
		txtApellidos.setBounds(196, 159, 86, 20);
		contentPane.add(txtApellidos);

		txtEps = new JTextField();
		txtEps.setColumns(10);
		txtEps.setBounds(196, 189, 86, 20);
		contentPane.add(txtEps);

		txtFechaNacimiento = new JTextField();
		txtFechaNacimiento.setColumns(10);
		txtFechaNacimiento.setBounds(196, 214, 86, 20);
		contentPane.add(txtFechaNacimiento);

		txtCorreo = new JTextField();
		txtCorreo.setColumns(10);
		txtCorreo.setBounds(196, 239, 86, 20);
		contentPane.add(txtCorreo);

		txtEstadoCivil = new JTextField();
		txtEstadoCivil.setColumns(10);
		txtEstadoCivil.setBounds(196, 264, 86, 20);
		contentPane.add(txtEstadoCivil);

		txtTelefono = new JTextField();
		txtTelefono.setColumns(10);
		txtTelefono.setBounds(196, 289, 86, 20);
		contentPane.add(txtTelefono);

		txtDireccion = new JTextField();
		txtDireccion.setColumns(10);
		txtDireccion.setBounds(196, 314, 86, 20);
		contentPane.add(txtDireccion);

		txtAlergias = new JTextField();
		txtAlergias.setColumns(10);
		txtAlergias.setBounds(196, 339, 86, 20);
		contentPane.add(txtAlergias);

		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				Clientesclass crear = new Clientesclass();

				crear.create(Integer.parseInt(txtTipoDocumento.getText()),
						Integer.parseInt(txtNumeroDocumento.getText()), txtNombres.getText(), txtApellidos.getText(),
						txtEps.getText(), txtFechaNacimiento.getText(), txtCorreo.getText(), txtEstadoCivil.getText(),
						txtTelefono.getText(), txtDireccion.getText(), txtAlergias.getText());

			}
		});
		btnRegistrar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnRegistrar.setBounds(313, 110, 110, 23);
		contentPane.add(btnRegistrar);

		JLabel lblNewLabel = new JLabel("Sistema de Gestión de Clientes");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel.setBounds(96, 22, 301, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblIdClientes = new JLabel("Id Clientes");
		lblIdClientes.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblIdClientes.setBounds(30, 53, 163, 14);
		contentPane.add(lblIdClientes);
		
		txtTipoDocumento = new JTextField();
		txtTipoDocumento.setColumns(10);
		txtTipoDocumento.setBounds(194, 79, 86, 20);
		contentPane.add(txtTipoDocumento);
		
		JButton btnEliminar = new JButton("Eliminar");
		btnEliminar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				Clientesclass Dl = new Clientesclass();
				Dl.delete(Integer.parseInt(txtIdClientes.getText()));
				txtIdClientes.setText("");
			}
		});
		btnEliminar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnEliminar.setBounds(313, 161, 110, 23);
		contentPane.add(btnEliminar);
		
		JButton btnActualizar = new JButton("Actualizar");
		btnActualizar.addMouseListener(new MouseAdapter() {
			@Override//Actializar
			public void mouseClicked(MouseEvent e) {
				Clientesclass Up = new Clientesclass();
				Up.update(Integer.parseInt(txtIdClientes.getText()), Integer.parseInt(txtTipoDocumento.getText()),Integer.parseInt(txtNumeroDocumento.getText()),txtNombres.getText(),txtApellidos.getText(),txtEps.getText(),txtFechaNacimiento.getText(),txtCorreo.getText(),txtEstadoCivil.getText(),txtTelefono.getText(),txtDireccion.getText(),txtAlergias.getText());
				
			}
		});
		btnActualizar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnActualizar.setBounds(313, 212, 110, 23);
		contentPane.add(btnActualizar);
		
		JButton btnMostrar = new JButton("Mostrar");
		btnMostrar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			Clientesclass Ro = new Clientesclass();

			Ro.readOne(Integer.parseInt(txtIdClientes.getText()), txtTipoDocumento, txtNumeroDocumento, txtNombres, txtApellidos, txtEps, txtFechaNacimiento, txtCorreo, txtEstadoCivil, txtTelefono, txtDireccion, txtAlergias);
			
			
			
			}
		});
		btnMostrar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnMostrar.setBounds(313, 263, 110, 23);
		contentPane.add(btnMostrar);
	}
}
