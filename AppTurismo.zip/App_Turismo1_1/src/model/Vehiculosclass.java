package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

import controller.Conexion;

public class Vehiculosclass {

	String matricula;
	String marca;
	int puestos;
	String modelo;
	int numeromotor;
	String categoria;
	int fktipotranspo;

	public Vehiculosclass(String matricula, String marca, int puestos, String modelo, int numeromotor, String categoria,
			int fktipotranspo) {
		super();
		this.matricula = matricula;
		this.marca = marca;
		this.puestos = puestos;
		this.modelo = modelo;
		this.numeromotor = numeromotor;
		this.categoria = categoria;
		this.fktipotranspo = fktipotranspo;
	}

	public Vehiculosclass() {
		super();
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public int getPuestos() {
		return puestos;
	}

	public void setPuestos(int puestos) {
		this.puestos = puestos;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public int getNumeromotor() {
		return numeromotor;
	}

	public void setNumeromotor(int numeromotor) {
		this.numeromotor = numeromotor;
	}

	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public int getFktipotranspo() {
		return fktipotranspo;
	}

	public void setFktipotranspo(int fktipotranspo) {
		this.fktipotranspo = fktipotranspo;
	}

	Conexion conector = new Conexion();

	public void create(String matricula, String marca, int puestos, String modelo, int numeromotor, String categoria,
			int fktipotranspo) {
		Connection dbConnection = null;
		PreparedStatement pst = null;

		String crear = "Insert Into tblvehiculos ( matricula, marca, puestos, modelo,  numeromotor, categoria,  fktipotranspo) values (?,?,?,?,?,?,?)";

		try {
			dbConnection = conector.conectarBD();
			pst = dbConnection.prepareStatement(crear);

			pst.setString(1, matricula);
			pst.setString(2, marca);
			pst.setInt(3, puestos);
			pst.setString(4, modelo);
			pst.setInt(5, numeromotor);
			pst.setString(6, categoria);
			pst.setInt(7, fktipotranspo);

			pst.executeUpdate();

			JOptionPane.showMessageDialog(null, "Registro con Exito");

		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}

	}

	public void delete(String matricula) {
		Connection dbConnection = null;
		PreparedStatement pst = null;

		String script = "DELETE FROM tblvehiculos WHERE matricula = ?";

		try {
			dbConnection = conector.conectarBD(); // Abrir la conexion
			pst = dbConnection.prepareStatement(script); // Abrir el buffer

			// Parametrizar el campo
			pst.setString(1, matricula);

			int resp = JOptionPane.showConfirmDialog(null, "Desea eliminar el registro No." + matricula + " ?");

			if (resp == JOptionPane.YES_OPTION) {
				pst.executeUpdate();
				JOptionPane.showMessageDialog(null, "Registro No. " + matricula + " Eliminado");
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

	public void update(String matricula, String marca, int puestos, String modelo, int numeromotor, String categoria,
			int fktipotranspo) {
		Connection dbConnection = null;
		PreparedStatement pst = null;

		String script = "UPDATE tblvehiculos SET marca = ?, puestos = ?, modelo = ?, numeromotor = ?, categoria = ?, fktipotranspo = ? WHERE matricula = ?;";

		try {
			dbConnection = conector.conectarBD(); // abrir la conexión
			pst = dbConnection.prepareStatement(script); // preparar el statement

			// parametrizar los campos
			pst.setString(1, marca);
			pst.setInt(2, puestos);
			pst.setString(3, modelo);
			pst.setInt(4, numeromotor);
			pst.setString(5, categoria);
			pst.setInt(6, fktipotranspo);
			pst.setString(7, matricula); // clave primaria para el WHERE

			// confirmar la operación
			int resp = JOptionPane.showConfirmDialog(null, "¿Desea actualizar esta fila?");

			if (resp == JOptionPane.OK_OPTION) {
				pst.executeUpdate();
				JOptionPane.showMessageDialog(null, "Fila actualizada");
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

	public void readOne(String matricula, JTextField marca, JTextField puestos, JTextField modelo,
			JTextField numeromotor,JTextField categoria, JTextField fktipotransporte) {

		Connection dbConnection = null;
		PreparedStatement pst = null;

		String script = "SELECT * FROM tblvehiculos WHERE matricula = ?;";

		try {
			dbConnection = conector.conectarBD(); // abrir conexión
			pst = dbConnection.prepareStatement(script); // preparar SQL

			pst.setString(1, matricula); // establecer el valor de la matrícula

			ResultSet rs = pst.executeQuery(); // ejecutar consulta

			while (rs.next()) {
				marca.setText(rs.getString(2));
				puestos.setText(String.valueOf(rs.getInt(3)));
				modelo.setText(rs.getString(4));
				numeromotor.setText(String.valueOf(rs.getInt(5)));
				categoria.setText(rs.getString(6));
				fktipotransporte.setText(String.valueOf(rs.getInt(7)));
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

}
