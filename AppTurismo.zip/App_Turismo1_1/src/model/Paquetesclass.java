package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

import controller.Conexion;

public class Paquetesclass {

	int idpaquetes;
	int iddestino;
	int idorigen;
	String fechaventa;
	String horaventa;
	String horasalida;
	String fechaejecucion;
	String observacion;
	int fkclientes;
	int fkpromotor;
	int fkagencia;
	int fkmedio;
	String precios;
	String fkmatricula;

	public Paquetesclass(int iddestino, int idorigen, String fechaventa, String horaventa, String horasalida,
			String fechaejecucion, String observacion, int fkclientes, int fkpromotor, int fkagencia, int fkmedio,
			String precios, String fkmatricula, int idpaquetes) {
		super();
		this.iddestino = iddestino;
		this.idorigen = idorigen;
		this.fechaventa = fechaventa;
		this.horaventa = horaventa;
		this.horasalida = horasalida;
		this.fechaejecucion = fechaejecucion;
		this.observacion = observacion;
		this.fkclientes = fkclientes;
		this.fkpromotor = fkpromotor;
		this.fkagencia = fkagencia;
		this.fkmedio = fkmedio;
		this.precios = precios;
		this.fkmatricula = fkmatricula;
	}

	public Paquetesclass() {
		super();
	}

	public int getIdpaquetes() {
		return idpaquetes;
	}

	public void setIdpaquetes(int idpaquetes) {
		this.idpaquetes = idpaquetes;
	}

	public int getIddestino() {
		return iddestino;
	}

	public void setIddestino(int iddestino) {
		this.iddestino = iddestino;
	}

	public int getIdorigen() {
		return idorigen;
	}

	public void setIdorigen(int idorigen) {
		this.idorigen = idorigen;
	}

	public String getFechaventa() {
		return fechaventa;
	}

	public void setFechaventa(String fechaventa) {
		this.fechaventa = fechaventa;
	}

	public String getHoraventa() {
		return horaventa;
	}

	public void setHoraventa(String horaventa) {
		this.horaventa = horaventa;
	}

	public String getHorasalida() {
		return horasalida;
	}

	public void setHorasalida(String horasalida) {
		this.horasalida = horasalida;
	}

	public String getFechaejecucion() {
		return fechaejecucion;
	}

	public void setFechaejecucion(String fechaejecucion) {
		this.fechaejecucion = fechaejecucion;
	}

	public String getObservacion() {
		return observacion;
	}

	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}

	public int getFkclientes() {
		return fkclientes;
	}

	public void setFkclientes(int fkclientes) {
		this.fkclientes = fkclientes;
	}

	public int getFkpromotor() {
		return fkpromotor;
	}

	public void setFkpromotor(int fkpromotor) {
		this.fkpromotor = fkpromotor;
	}

	public int getFkagencia() {
		return fkagencia;
	}

	public void setFkagencia(int fkagencia) {
		this.fkagencia = fkagencia;
	}

	public int getFkmedio() {
		return fkmedio;
	}

	public void setFkmedio(int fkmedio) {
		this.fkmedio = fkmedio;
	}

	public String getPrecios() {
		return precios;
	}

	public void setPrecios(String precios) {
		this.precios = precios;
	}

	public String getFkmatricula() {
		return fkmatricula;
	}

	public void setFkmatricula(String fkmatricula) {
		this.fkmatricula = fkmatricula;
	}

	Conexion conector = new Conexion();

	public void create(int iddestino, int idorigen, String fechaventa, String horaventa, String horasalida,
			String fechaejecucion, String observacion, int fkclientes, int fkpromotor, int fkagencia, int fkmedio,
			String precios, String fkmatricula) {
		Connection dbConnection = null;
		PreparedStatement pst = null;

		String script = "Insert Into tblpaquetes(iddestino, idorigen,fechaventa, horaventa,horasalida,fechaejecucion,observacion,fkclientes,fkpromotor,fkagencia,fkmedio, precios, fkmatricula) values (?,?,?,?,?,?,?,?,?,?,?,?,?)";

		try {
			dbConnection = conector.conectarBD();
			pst = dbConnection.prepareStatement(script);

			pst.setInt(1, iddestino);
			pst.setInt(2, idorigen);
			pst.setString(3, fechaventa);
			pst.setString(4, horaventa);
			pst.setString(5, horasalida);
			pst.setString(6, fechaejecucion);
			pst.setString(7, observacion);
			pst.setInt(8, fkclientes);
			pst.setInt(9, fkpromotor);
			pst.setInt(10, fkagencia);
			pst.setInt(11, fkmedio);
			pst.setString(12, precios);
			pst.setString(13, fkmatricula);
			pst.executeUpdate();

			JOptionPane.showMessageDialog(null, "Registro con Exito");

		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}

	}

	public void delete(int idpaquetes) {
		Connection dbConnection = null;
		PreparedStatement pst = null;

		String script = "DELETE FROM tblpaquetes WHERE idpaquetes = ?";

		try {
			dbConnection = conector.conectarBD(); // Abrir la conexion
			pst = dbConnection.prepareStatement(script); // Abrir el buffer

			// Parametrizar el campo
			pst.setInt(1, idpaquetes);

			int resp = JOptionPane.showConfirmDialog(null, "Desea eliminar el registro No." + idpaquetes + " ?");

			if (resp == JOptionPane.YES_OPTION) {
				pst.executeUpdate();
				JOptionPane.showMessageDialog(null, "Registro No. " + idpaquetes + " Eliminado");
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

	public void update(int idpaquetes, int iddestino, int idorigen, String fechaventa, String horaventa,
			String horasalida, String fechaejecucion, String observacion, int fkclientes, int fkpromotor, int fkagencia,
			int fkmedio, String precios, String fkmatricula) {

		Connection dbConnection = null;
		PreparedStatement pst = null; // preparar la trx

		String script = "UPDATE tblpaquetes SET iddestino = ?,idorigen = ?, fechaventa = ?, horaventa = ?, horasalida = ?,\r\n"
				+ "			fechaejecucion = ?, observacion = ?, fkclientes = ?, fkpromotor = ?, fkagencia = ?,fkmedio = ?,\r\n"
				+ "			precios =  ?, fkmatricula = ? WHERE idpaquetes = ?;";

		try {
			dbConnection = conector.conectarBD(); // abrir la conexion
			pst = dbConnection.prepareStatement(script); // abrir el buffer

			// parametrizar el campo

			pst.setInt(1, iddestino);
			pst.setInt(2, idorigen);
			pst.setString(3, fechaventa);
			pst.setString(4, horaventa);
			pst.setString(5, horasalida);
			pst.setString(6, fechaejecucion);
			pst.setString(7, observacion);
			pst.setInt(8, fkclientes);
			pst.setInt(9, fkpromotor);
			pst.setInt(10, fkagencia);
			pst.setInt(11, fkmedio);
			pst.setString(12, precios);
			pst.setString(13, fkmatricula);
			pst.setInt(14, idpaquetes);

			// confirmar la operacion
			int resp = JOptionPane.showConfirmDialog(null, "¿desea actualizar esta fila?");

			if (resp == JOptionPane.OK_OPTION) {
				pst.executeUpdate();
				JOptionPane.showConfirmDialog(null, "fila actualizada");
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

	public void readOne(int idpaquetes, JTextField iddestino, JTextField idorigen, JTextField fechaventa,
			JTextField horaventa, JTextField horasalida, JTextField fechaejecucion, JTextField observacion,
			 JTextField fkclientes,JTextField fkpromotor, JTextField fkagencia, JTextField fkmedio,JTextField precio,
			JTextField fkmatricula) {

		Connection dbConnection = null;
		PreparedStatement pst = null;

		String script = "SELECT * FROM tblpaquetes WHERE idpaquetes = ?;";

		try {
			dbConnection = conector.conectarBD(); // abrir conexión
			pst = dbConnection.prepareStatement(script); // preparar SQL

			pst.setInt(1, idpaquetes); // asignar parámetro

			ResultSet rs = pst.executeQuery(); // ejecutar consulta

			while (rs.next()) {
				iddestino.setText(rs.getString(2));
				idorigen.setText(rs.getString(3));
				fechaventa.setText(rs.getString(4));
				horaventa.setText(rs.getString(5));
				horasalida.setText(rs.getString(6));
				fechaejecucion.setText(rs.getString(7));
				observacion.setText(rs.getString(8));
				fkclientes.setText(rs.getString(9));
				fkpromotor.setText(rs.getString(10));
				fkagencia.setText(rs.getString(11));
				fkmedio.setText(rs.getString(12));
				precio.setText(rs.getString(13));
				fkmatricula.setText(rs.getString(14));
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

}
