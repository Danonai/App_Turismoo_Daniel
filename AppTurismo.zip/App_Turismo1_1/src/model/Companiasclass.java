package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

import controller.Conexion;

public class Companiasclass {

	int idcompania;
	String razonsocial;
	String direccion;
	String correo;
	String telefono;
	String fechaCreacion;
	String web;

	public Companiasclass(int idcompania, String razonsocial, String direccion, String correo, String telefono,
			String fechaCreacion, String web) {
		super();
		this.razonsocial = razonsocial;
		this.direccion = direccion;
		this.correo = correo;
		this.telefono = telefono;
		this.fechaCreacion = fechaCreacion;
		this.web = web;
	}

	public Companiasclass(int idcompania) {
		super();
		this.idcompania = idcompania;
	}

	public int getIdcompanias() {
		return idcompania;
	}

	public void setIdcompanias(int idcompania) {
		this.idcompania = idcompania;
	}

	public Companiasclass() {
		super();
	}

	public String getRazonsocial() {
		return razonsocial;
	}

	public void setRazonsocial(String razonsocial) {
		this.razonsocial = razonsocial;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(String fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public String getWeb() {
		return web;
	}

	public void setWeb(String web) {
		this.web = web;
	}

	Conexion conector = new Conexion();

	public void create(String razonsocial, String direccion, String correo, String telefono, String fechaCreacion,
			String web) {
		Connection dbConnection = null;
		PreparedStatement pst = null;

		String script = "Insert Into tblcompanias (razonsocial,direccion,correo, telefono,fechaCreacion,web) values (?,?,?,?,?,?)";

		try {
			dbConnection = conector.conectarBD();
			pst = dbConnection.prepareStatement(script);

			pst.setString(1, razonsocial);
			pst.setString(2, direccion);
			pst.setString(3, correo);
			pst.setString(4, telefono);
			pst.setString(5, fechaCreacion);
			pst.setString(6, web);

			pst.executeUpdate();

			JOptionPane.showConfirmDialog(null, "Registro con Exito");

		} catch (Exception e) {

		}

	}

	public void delete(int idcompania) {
		Connection dbConnection = null;
		PreparedStatement pst = null;

		String script = "DELETE FROM tblcompanias WHERE idcompania = ?";

		try {
			dbConnection = conector.conectarBD(); // Abrir la conexion
			pst = dbConnection.prepareStatement(script); // Abrir el buffer

			// Parametrizar el campo
			pst.setInt(1, idcompania);

			int resp = JOptionPane.showConfirmDialog(null, "Desea eliminar el registro No." + idcompania + " ?");

			if (resp == JOptionPane.YES_OPTION) {
				pst.executeUpdate();
				JOptionPane.showMessageDialog(null, "Registro No. " + idcompania + " Eliminado");
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

	public void update(int idcompania, String razonsocial, String direccion, String correo, String telefono,
			String fechaCreacion, String web) {

		Connection dbConnection = null;
		PreparedStatement pst = null; // preparar la trx

		String script = "UPDATE tblcompanias SET  razonsocial = ?, direccion = ?, correo = ?, telefono = ?,  fechaCreacion = ?,  web = ? WHERE idcompania  = ?";

		try {
			dbConnection = conector.conectarBD(); // abrir la conexion
			pst = dbConnection.prepareStatement(script); // abrir el buffer

			// parametrizar el campo

			pst.setString(1, razonsocial);
			pst.setString(2, direccion);
			pst.setString(3, correo);
			pst.setString(4, telefono);
			pst.setString(5, fechaCreacion);
			pst.setString(6, web);
			pst.setInt(7, idcompania);

			// confirmar la operacion
			int resp = JOptionPane.showConfirmDialog(null, "¿desea actualizar esta fila?");

			if (resp == JOptionPane.OK_OPTION) {
				pst.executeUpdate();
				JOptionPane.showConfirmDialog(null, "fila actualizada");
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

	public void readOne(int idcompania, JTextField razonsocial, JTextField direccion, JTextField correo,
			JTextField telefono, JTextField fechacreacion, JTextField web) {

		Connection dbConnection = null;
		PreparedStatement pst = null;

		String script = "SELECT * FROM tblcompanias WHERE idcompania = ?;";

		try {
			dbConnection = conector.conectarBD(); // abrir la conexión
			pst = dbConnection.prepareStatement(script); // preparar la sentencia SQL

			pst.setInt(1, idcompania); // establecer el valor del parámetro

			ResultSet rs = pst.executeQuery(); // ejecutar consulta

			while (rs.next()) {
				razonsocial.setText(rs.getString(2));
				direccion.setText(rs.getString(3));
				correo.setText(rs.getString(4));
				telefono.setText(rs.getString(5));
				fechacreacion.setText(rs.getString(6));
				web.setText(rs.getString(7));
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

}
